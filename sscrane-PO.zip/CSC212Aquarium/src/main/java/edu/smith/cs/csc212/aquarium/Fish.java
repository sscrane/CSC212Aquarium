package edu.smith.cs.csc212.aquarium;
import java.util.Random;
import java.awt.Color;
import java.awt.Graphics2D;
import java.lang.reflect.Array;


public class Fish {
	int x;
	int y;
	int newx;
	int newy;
	int speed;
	Color color;
	int facing;
	boolean isLittle;
	int hunger;
	boolean hungry;
	
	public Fish (int x, int y, int speed, Color color, boolean isLittle, int hunger) {
		this.color = color;
		this.x = x;
		this.y = y;
		this.newx = x;
		this.newy = y;
		this.speed = speed;
		this.facing = 1;
		this.isLittle = isLittle;
		this.hunger = hunger;
		this.hungry = false;
		
	}
	
	public void moveFish(Graphics2D g) {
		if (Math.abs(this.x- this.newx) < 5 && Math.abs(this.y- this.newy) < 5) {
			Random ran = new Random(); 
			if (this.hungry == true) {
				this.hunger = 200;
				this.hungry = false;
			}if (this.hunger < 10) {
				int randx = ran.nextInt(100);
				int randy = ran.nextInt(100);
				this.newx = randx;
				this.newy = randy;
				this.hungry = true;
			}else {
				int randx = ran.nextInt(500);
				int randy = ran.nextInt(500);
				this.newx = randx;
				this.newy = randy;
			}
		}this.hunger --;
		
			if (this.x < this.newx) {  //face right
				this.x += this.speed;
				this.facing = 1;
			}else if (this.x > this.newx) { //face left
				this.x -= this.speed;
				this.facing = -1;
			}if (this.y < this.newy) {
				this.y += this.speed;
			}else if (this.y > this.newy) {
				this.y -= this.speed;
			}
		if (this.facing == 1) {
			if (this.isLittle == true) {
				DrawFish.smallFacingRight(g, this.color, this.x, this.y, this.hungry);
			}else {
				DrawFish.facingRight(g, this.color, this.x, this.y, this.hungry);
			}
		}else {
			if (this.isLittle == true) {
				DrawFish.smallFacingLeft(g, this.color, this.x, this.y, this.hungry);
			}else {
				DrawFish.facingLeft(g, this.color, this.x, this.y, this.hungry);
			}
		
		}
	}
}
