package edu.smith.cs.csc212.aquarium;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.Shape;
import java.awt.geom.Ellipse2D;
import java.util.Random;

public class bubble {
	int size;
	int x;
	int y;
	public bubble(int size, int x, int y) {
		this.x = x;
		this.y = y;
		this.size = size;
	}
	public void drawBubble(Graphics2D g) {
		Random ran = new Random();
		int movex = ran.nextInt(5);
		this.y --;
		if (movex == 1) {
			this.x ++;
		}else if (movex == 3) {
			this.x --;
		}	
		Shape bubble = new Ellipse2D.Double(this.x,this.y,size,size);
		if (this.y < (0 - this.size)) {
			this.y = 550;
		}
		g.setColor(Color.blue);
		g.draw(bubble);
		g.setColor(Color.cyan);
		g.fill(bubble);
		
	}
	
}
