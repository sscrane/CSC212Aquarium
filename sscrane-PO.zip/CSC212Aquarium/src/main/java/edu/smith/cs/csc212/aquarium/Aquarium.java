package edu.smith.cs.csc212.aquarium;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.Shape;
import java.awt.geom.Ellipse2D;
import java.util.Random;

import me.jjfoley.gfx.GFX;

/**
 * Aquarium is a graphical "application" that uses some code I built and have
 * shared with you that takes care of opening a window and communicating with
 * the user in a simple way.
 * 
 * The method draw is called 50 times per second, so we make an animation by
 * drawing our fish in one place, and moving that place slightly. The next time
 * draw gets called, our fish looks like it moved!
 * 
 * @author jfoley
 *
 */
public class Aquarium extends GFX {
	/**
	 * This is a static variable that tells us how wide the aquarium is.
	 */
	public static int WIDTH = 500;
	/**
	 * This is a static variable that tells us how tall the aquarium is.
	 */
	public static int HEIGHT = 500;

	/**
	 * Put a snail on the top of the tank.
	 */
	Snail algorithm = new Snail(177, Snail.HEIGHT + 1, "top", WIDTH, HEIGHT);

	/**
	 * This is a constructor, code that runs when we make a new Aquarium.
	 */
	public Aquarium() {
		// Here we ask GFX to make our window of size WIDTH and HEIGHT.
		// Don't change this here, edit the variables instead.
		super(WIDTH, HEIGHT);
	}

	int fish1X = getWidth() + 100;
	int fish2X = getWidth() + 300;
	
	Fish fish1 = new Fish(100,100,1,Color.pink, true, 200); //x,y,speed,color, isLittle
	Fish fish2 = new Fish(200,100,1,Color.blue, true, 150);
	Fish fish3 = new Fish(300,100,1,Color.green,false, 100);
	
	bubble bubble1 = new bubble(20, 200, 500);
	bubble bubble2 = new bubble(30, 300, 550);
	bubble bubble3 = new bubble(20, 100, 600);
	bubble bubble4 = new bubble(10, 400, 750);
	
	//red, green, blue
	int green = 50;
	boolean greening = true;
	@Override
	public void draw(Graphics2D g) {

		Random rand = new Random();
		// Draw the "ocean" background.
		if (greening == true) {
	    	int t = rand.nextInt(2);
	    	if (t == 1) {
	    		green ++;
	    	}if (green > 200) {
				algorithm.draw(g, green);
				algorithm.isMoving = true;
				greening = false;
		}
		}else if (greening == false){
	    	int t = rand.nextInt(3);
	    	if (t == 1) {
	    		green --;
	    	}
			if (green <= 50) {
				greening = true;
				algorithm.isMoving = false;
				algorithm.move();
			}
		}

		Color aquariumColor = new Color(0, green, 150);
		g.setColor(aquariumColor);
		g.fillRect(0, 0, getWidth(), getHeight());
		
		Shape food = new Ellipse2D.Double(40, 20, 10, 10);
		Shape food2 = new Ellipse2D.Double(20, 10, 10, 10);
		Shape food3 = new Ellipse2D.Double(40, 50, 10, 10);
		g.setColor(Color.lightGray);
		g.fill(food);
		g.draw(food);
		g.fill(food2);
		g.draw(food2);
		g.fill(food3);
		g.draw(food3);
		
		fish1.moveFish(g);
		fish2.moveFish(g);
		fish3.moveFish(g);
		
		bubble1.drawBubble(g);
		bubble2.drawBubble(g);
		bubble3.drawBubble(g);
		bubble4.drawBubble(g);

		// Draw our snail!
		algorithm.draw(g,green);


	}

	public static void main(String[] args) {
		// Uncomment this to make it go slower!
		// GFX.FPS = 10;
		// This is potentially helpful for debugging movement if there are too many print statements!

		// Note that we can store an Aquarium in a variable of type GFX because Aquarium
		// is a very specific GFX, much like 7 can be stored in a variable of type int!
		GFX app = new Aquarium();
		app.start();
	}

}
